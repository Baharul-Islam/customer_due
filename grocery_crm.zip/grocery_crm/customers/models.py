from django.db import models
from django.core.validators import MinLengthValidator
from django.utils import timezone
from django.db import models
from django.db.models import Sum

class Customer(models.Model):
    CUSTOMER_ID_PREFIX = 'GC'  # Grocery Customer prefix
    
    id = models.CharField(max_length=10, primary_key=True, editable=False)
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=15, unique=True)
    email = models.EmailField(blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    joining_date = models.DateField(auto_now_add=True)
    profile_picture = models.ImageField(upload_to='customer_profiles/', blank=True, null=True)
    additional_info = models.TextField(blank=True, null=True)
    
    def save(self, *args, **kwargs):
        if not self.id:
            # Generate customer ID if not provided
            last_customer = Customer.objects.order_by('id').last()
            if last_customer:
                last_id = int(last_customer.id[2:])  # Remove prefix
                new_id = f"{self.CUSTOMER_ID_PREFIX}{str(last_id + 1).zfill(4)}"
            else:
                new_id = f"{self.CUSTOMER_ID_PREFIX}0001"
            self.id = new_id
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.name} ({self.id})"

class Purchase(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='purchases')
    date = models.DateTimeField(auto_now_add=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    paid_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    due_amount = models.DecimalField(max_digits=10, decimal_places=2, editable=False)
    items = models.TextField()
    notes = models.TextField(blank=True, null=True)
    
    def save(self, *args, **kwargs):
        self.due_amount = self.total_amount - self.paid_amount
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"Purchase #{self.id} - {self.customer.name} (৳{self.total_amount})"

class Payment(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='payments')
    date = models.DateTimeField(default=timezone.now)
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    payment_method = models.CharField(max_length=50, choices=[
        ('cash', 'Cash'),
        ('card', 'Card'),
        ('bkash', 'bKash'),
        ('nagad', 'Nagad'),
        ('bank', 'Bank Transfer'),
    ])
    notes = models.TextField(blank=True, null=True)
    
    def __str__(self):
        return f"Payment #{self.id} - {self.customer.name}"
    def get_total_paid(self):
        """Calculate total paid from both purchase payments and payment records"""
        # Sum of paid_amount from all purchases
        purchase_payments = self.purchases.aggregate(
            total=Sum('paid_amount')
        )['total'] or 0
        
        # Sum of amount from all payment records
        additional_payments = self.payments.aggregate(
            total=Sum('amount')
        )['total'] or 0
        
        return purchase_payments + additional_payments

    def get_total_due(self):
        """Calculate current due amount (total purchases - total paid)"""
        total_purchases = self.get_total_purchases()
        total_paid = self.get_total_paid()
        return total_purchases - total_paid