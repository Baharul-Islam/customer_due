from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db.models import Q, Sum
from .models import Customer, Purchase, Payment
from .forms import CustomerForm, PurchaseForm, PaymentForm, CustomerSearchForm

from django.db.models import Sum
from .models import Customer
from django.db.models import Sum, Q
from django.db.models.functions import Coalesce
from django.db.models import Sum, F, Value
from django.db.models import Sum, F, DecimalField
from django.db.models import Value


def customer_list(request):
    # Annotate each customer with their total due amount
    customers = Customer.objects.annotate(
        total_due=Sum('purchases__due_amount')
    ).order_by('-joining_date')

    # Search functionality (keep your existing code)
    form = CustomerSearchForm(request.GET or None)
    if form.is_valid() and form.cleaned_data['search_query']:
        query = form.cleaned_data['search_query']
        customers = customers.filter(
            Q(name__icontains=query) | 
            Q(id__icontains=query) |
            Q(phone__icontains=query)
        )

    context = {
        'customers': customers,
        'form': form,
    }
    return render(request, 'customers/customer_list.html', context)

def customer_detail(request, customer_id):
    customer = get_object_or_404(Customer, id=customer_id)
    purchases = customer.purchases.all().order_by('-date')
    payments = customer.payments.all().order_by('-date')
    
    # Calculate summary
    total_purchases = purchases.aggregate(total=Sum('total_amount'))['total'] or 0
    total_paid = purchases.aggregate(total=Sum('paid_amount'))['total'] or 0
    total_due = purchases.aggregate(total=Sum('due_amount'))['total'] or 0
    total_payments = payments.aggregate(total=Sum('amount'))['total'] or 0
    combined_total = total_paid + total_payments
    combined_due=total_due-total_payments
    
    context = {
        'customer': customer,
        'purchases': purchases,
        'payments': payments,
        'combined_total': combined_total,
        'combined_due': combined_due,
        'total_purchases': total_purchases,
        'total_paid': total_paid,
        'total_due': total_due,
        'total_payments': total_payments,
        'net_balance': total_due - total_payments,
    }
    return render(request, 'customers/customer_detail.html', context)

def add_customer(request):
    if request.method == 'POST':
        form = CustomerForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Customer added successfully!')
            return redirect('customer_list')
    else:
        form = CustomerForm()
    
    return render(request, 'customers/add_customer.html', {'form': form})

def edit_customer(request, customer_id):
    customer = get_object_or_404(Customer, id=customer_id)
    if request.method == 'POST':
        form = CustomerForm(request.POST, request.FILES, instance=customer)
        if form.is_valid():
            form.save()
            messages.success(request, 'Customer updated successfully!')
            return redirect('customer_detail', customer_id=customer.id)
    else:
        form = CustomerForm(instance=customer)
    
    return render(request, 'customers/edit_customer.html', {'form': form, 'customer': customer})

def add_purchase(request, customer_id):
    customer = get_object_or_404(Customer, id=customer_id)
    
    if request.method == 'POST':
        form = PurchaseForm(request.POST)
        if form.is_valid():
            purchase = form.save(commit=False)
            purchase.customer = customer  # Set customer from URL parameter
            purchase.due_amount = purchase.total_amount - (purchase.paid_amount or 0)
            purchase.save()
            messages.success(request, f'Purchase of ৳{purchase.total_amount} added successfully!')
            return redirect('customer_detail', customer_id=customer.id)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = PurchaseForm()
    
    return render(request, 'customers/add_purchase.html', {
        'form': form,
        'customer': customer
    })



def add_payment(request, customer_id):
    customer = get_object_or_404(Customer, id=customer_id)
    
    if request.method == 'POST':
        form = PaymentForm(request.POST)
        if form.is_valid():
            payment = form.save(commit=False)
            payment.customer = customer  # Set customer from URL
            payment.save()
            messages.success(request, f'Payment of ৳{payment.amount} recorded successfully!')
            return redirect('customer_detail', customer_id=customer.id)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = PaymentForm()
    
    return render(request, 'customers/add_payment.html', {
        'form': form,
        'customer': customer
    })

def due_customers(request):
    customers = Customer.objects.annotate(
        total_purchases_due=Coalesce(
            Sum('purchases__due_amount', output_field=DecimalField(max_digits=12, decimal_places=2)),
            Value(0, output_field=DecimalField(max_digits=12, decimal_places=2))
        ),
        total_payments=Coalesce(
            Sum('payments__amount', output_field=DecimalField(max_digits=12, decimal_places=2)),
            Value(0, output_field=DecimalField(max_digits=12, decimal_places=2))
        ),
        net_balance=F('total_purchases_due') - F('total_payments')
    ).filter(net_balance__gt=0).order_by('-net_balance')
    
    return render(request, 'customers/due_customers.html', {
        'customers': customers
    })