from django.contrib import admin
from .models import Customer, Purchase, Payment

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'phone', 'email', 'joining_date')
    search_fields = ('id', 'name', 'phone', 'email')
    list_filter = ('joining_date',)
    ordering = ('-joining_date',)

@admin.register(Purchase)
class PurchaseAdmin(admin.ModelAdmin):
    list_display = ('id', 'customer', 'date', 'total_amount', 'paid_amount', 'due_amount')
    list_filter = ('date', 'customer')
    search_fields = ('customer__name', 'customer__id', 'items')
    date_hierarchy = 'date'

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ('id', 'customer', 'date', 'amount', 'payment_method')
    list_filter = ('date', 'payment_method', 'customer')
    search_fields = ('customer__name', 'customer__id', 'notes')
    date_hierarchy = 'date'