from django.urls import path
from . import views

urlpatterns = [
    path('', views.customer_list, name='customer_list'),
    path('add/', views.add_customer, name='add_customer'),
    # Move due-customers ABOVE the customer_id pattern
    path('due-customers/', views.due_customers, name='due_customers'),
    # Keep customer_id patterns below
    path('<str:customer_id>/', views.customer_detail, name='customer_detail'),
    path('<str:customer_id>/edit/', views.edit_customer, name='edit_customer'),
    path('<str:customer_id>/add-purchase/', views.add_purchase, name='add_purchase'),
    path('<str:customer_id>/add-payment/', views.add_payment, name='add_payment'), 
]